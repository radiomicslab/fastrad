## Section 3: Runtime Performance

> - Totals and speedups: ONE full extraction call per timing (all classes), never summed per-class calls.
> - 20 repetitions after 3 warm-up; median [IQR]; `time.perf_counter()`; `torch.cuda.synchronize()` before and after every timed GPU call.
> - Image and mask loaded once before timing (file I/O excluded).
> - Single-thread: OMP/MKL/OpenBLAS pinned to 1, `torch.set_num_threads(1)`, SimpleITK 1 thread.
> - Image: lung1_image.nrrd, shape (134, 512, 512) (z,y,x), spacing (3.0, 0.9766, 0.9766) mm; clinical mask 56637 voxels, label values [0, 1].
> - Synthetic 15 mm sphere: 4631 voxels. GPU: NVIDIA GeForce RTX 4070. PyTorch 2.11.0+cu130.

### 3.1 End-to-end extraction time

#### Synthetic 15 mm sphere (4631 voxels): end-to-end, one full extraction call

| Configuration | Median [IQR] (s) | Features returned | Speedup vs PyRadiomics |
|---|---|---|---|
| PyRadiomics, 1 thread | 2.3786 [0.0408] | 107 | 1.00x |
| fastrad CPU, 1 thread | 0.0218 [0.0002] | 112 | 108.88x |
| fastrad GPU | 0.0164 [0.0001] | 112 | 145.34x |

#### Clinical case lung1_label.nrrd (56637 voxels): end-to-end, one full extraction call

| Configuration | Median [IQR] (s) | Features returned | Speedup vs PyRadiomics |
|---|---|---|---|
| PyRadiomics, 1 thread | 2.7048 [0.0381] | 107 | 1.00x |
| fastrad CPU, 1 thread | 0.2103 [0.0109] | 112 | 12.86x |
| fastrad GPU | 0.0292 [0.0007] | 112 | 92.48x |

### 3.2 Per-class breakdown

#### Synthetic 15 mm sphere (4631 voxels): per class (each class timed in its own call; fixed per-call overhead included, so rows must NOT be summed)

| Feature Class | PyRadiomics Median [IQR] (s) | fastrad CPU Median [IQR] (s) | CPU Speedup | fastrad GPU Median [IQR] (s) | GPU Speedup |
|---|---|---|---|---|---|
| shape | 2.4013 [0.0096] | 0.0067 [0.0001] | 359.99x | 0.0067 [0.0001] | 357.73x |
| firstorder | 2.3968 [0.0064] | 0.0025 [0.0001] | 972.83x | 0.0025 [0.0002] | 949.04x |
| glcm | 2.4030 [0.0055] | 0.0058 [0.0002] | 411.18x | 0.0048 [0.0003] | 499.74x |
| glrlm | 2.3999 [0.0083] | 0.0049 [0.0000] | 485.99x | 0.0031 [0.0001] | 784.74x |
| glszm | 2.4002 [0.0103] | 0.0045 [0.0001] | 528.21x | 0.0035 [0.0002] | 681.61x |
| gldm | 2.3830 [0.0299] | 0.0028 [0.0001] | 845.74x | 0.0032 [0.0002] | 740.98x |
| ngtdm | 2.3998 [0.0105] | 0.0033 [0.0001] | 716.93x | 0.0038 [0.0001] | 639.18x |

#### Clinical case lung1_label.nrrd (56637 voxels): per class (each class timed in its own call; fixed per-call overhead included, so rows must NOT be summed)

| Feature Class | PyRadiomics Median [IQR] (s) | fastrad CPU Median [IQR] (s) | CPU Speedup | fastrad GPU Median [IQR] (s) | GPU Speedup |
|---|---|---|---|---|---|
| shape | 2.6329 [0.0063] | 0.0283 [0.0001] | 93.13x | 0.0107 [0.0001] | 246.64x |
| firstorder | 2.4082 [0.0063] | 0.0111 [0.0001] | 216.23x | 0.0046 [0.0001] | 526.04x |
| glcm | 2.4062 [0.0342] | 0.0388 [0.0005] | 62.05x | 0.0099 [0.0002] | 243.59x |
| glrlm | 2.4222 [0.0055] | 0.0675 [0.0004] | 35.89x | 0.0053 [0.0001] | 457.09x |
| glszm | 2.4139 [0.0034] | 0.0756 [0.0022] | 31.95x | 0.0102 [0.0001] | 235.57x |
| gldm | 2.4099 [0.0063] | 0.0132 [0.0011] | 182.36x | 0.0056 [0.0002] | 431.94x |
| ngtdm | 2.4095 [0.0046] | 0.0192 [0.0001] | 125.52x | 0.0055 [0.0000] | 438.15x |

### 3.3 ROI size scaling (one full extraction call per timing)

| Radius (mm) | Voxel Count | PyRadiomics Median [IQR] (s) | fastrad CPU Median [IQR] (s) | CPU Speedup | fastrad GPU Median [IQR] (s) | GPU Speedup |
|---|---|---|---|---|---|---|
| 5 | 83 | 2.4017 [0.0068] | 0.0062 [0.0002] | 386.17x | 0.0124 [0.0000] | 193.87x |
| 10 | 1227 | 2.4021 [0.0022] | 0.0097 [0.0003] | 247.51x | 0.0139 [0.0001] | 173.24x |
| 15 | 4631 | 2.4170 [0.0048] | 0.0207 [0.0000] | 116.95x | 0.0165 [0.0001] | 146.27x |
| 20 | 9973 | 2.4382 [0.0079] | 0.0380 [0.0002] | 64.18x | 0.0202 [0.0000] | 120.91x |
| 25 | 20921 | 2.4692 [0.0051] | 0.0704 [0.0039] | 35.07x | 0.0248 [0.0001] | 99.40x |
| 30 | 37545 | 2.5173 [0.0100] | 0.1266 [0.0061] | 19.88x | 0.0289 [0.0001] | 87.06x |

### 3.4 Multi-threading (clinical case, one full extraction call)

- PyRadiomics, 1 thread: 2.7048 [0.0381] s
- PyRadiomics, 32 threads: 1.8456 [0.0306] s (threading speedup 1.47x)
- fastrad CPU, 1 thread: 0.2103 [0.0109] s

=> fastrad CPU 1 thread vs PyRadiomics 32 threads: 8.78x
